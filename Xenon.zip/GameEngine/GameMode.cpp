#include "GameMode.h"
#include "Scene.h"

// Intentionally minimal. The default EmptyGameMode does nothing.
