#include "Logger.h"

// Initialize static member
Logger* Logger::instance = nullptr;

