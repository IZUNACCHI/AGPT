#include "GameInstance.h"

// Intentionally empty - base class only.
