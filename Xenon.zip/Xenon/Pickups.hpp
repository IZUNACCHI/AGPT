#pragma once

// Convenience include for all pickup types.

#include "Pickup.hpp"
#include "AnimatedPickup.hpp"
#include "HealPickup.hpp"
#include "WeaponPickup.hpp"
#include "CompanionPickup.hpp"
