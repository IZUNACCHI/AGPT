#include "Texture.h"
#include "Renderer.h"


	struct Texture::Impl {
		SDL_Texture* texture = nullptr;
		Vector2i windowSize;

		// Constructor for Vector3i color key
		Impl(Renderer& renderer, const std::string& filePath, bool useColorKey, const Vector3i& colorKey) {
			// Create surface from file
			Surface surface(filePath);

			// Apply color key if requested
			if (useColorKey) {
				surface.SetColorKey(colorKey);
			}


			// Create texture from surface
			texture = SDL_CreateTextureFromSurface(
				renderer.GetNative(),
				surface.GetNative()
			);

			if (!texture) {
				THROW_ENGINE_EXCEPTION("Failed to create texture: ") << SDL_GetError();
			}

			// Get texture size
			windowSize = surface.GetSize();
		}

		~Impl() {
			if (texture) {
				SDL_DestroyTexture(texture);
			}
		}

		// No copying
		Impl(const Impl&) = delete;
		Impl& operator=(const Impl&) = delete;

		// Move semantics
		Impl(Impl&& other) noexcept : texture(other.texture), windowSize(other.windowSize) {
			other.texture = nullptr;
		}

		Impl& operator=(Impl&& other) noexcept {
			if (this != &other) {
				// Clean up current texture
				if (texture) {
					SDL_DestroyTexture(texture);
				}

				texture = other.texture;
				windowSize = other.windowSize;
				other.texture = nullptr;
			}
			return *this;
		}
	};


	Texture::Texture(Renderer& renderer, const std::string& filePath, bool useColorKey, const Vector3i& colorKey)
		: impl(std::make_unique<Impl>(renderer, filePath, useColorKey, colorKey)) {
	}

	// Constructor without color key
	Texture::Texture(Renderer& renderer, const std::string& filePath)
		: Texture(renderer, filePath, false, Vector3i::Zero()) {
	}

	Texture::~Texture() = default;  // unique_ptr handles destruction

	Texture::Texture(Texture&& other) noexcept
		: impl(std::move(other.impl)) {
	}

	Texture& Texture::operator=(Texture&& other) noexcept {
		if (this != &other) {
			impl = std::move(other.impl);
		}
		return *this;
	}

	Vector2i Texture::GetSize() const {
		return impl ? impl->windowSize : Vector2i(0, 0);
	}

	SDL_Texture* Texture::GetNative() const {
		return impl ? impl->texture : nullptr;
	}

	bool Texture::IsValid() const {
		return impl && impl->texture != nullptr;
	}
