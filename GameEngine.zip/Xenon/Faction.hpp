#pragma once

enum class Faction {
	Neutral = 0,
	Player,
	Enemy
};